//
//  ViewController.swift
//  RecyclerOregon
//
//  Created by Sadanand Lakka on 11/16/19.
//  Copyright © 2019 SQO. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate,
UINavigationControllerDelegate, UIPickerViewDelegate, UIPickerViewDataSource{
    
    var countyChoice = String()
    var trashType = String()
    var resultString = String()
    var recycleable = false
    var search = NSArray()
    
    @IBOutlet weak var trashTypePicker: UIPickerView!
    var trashData : [String] = [String]()
    
    @IBOutlet weak var countyPicker: UIPickerView!
    var countyData : [String] = [String]()
    
    @IBOutlet weak var cameraImg: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        cameraImg.image = UIImage(named: "recycling")
        countyData = ["Benton", "Clackamas", "Lane","Linn", "Marion","Multnomah"]
        trashData = ["Plastic Bottles", "Jugs", "Food Containers", "Styrofoam", "Plastic Bags", "Egg Containers", "Newspaper", "Cereal Boxes", "Magazines", "Catalogs", "Office Paper", "Milk/ Juice Carton", "Cardboard", "Aluminum", "Can", "Aluminum", "Foil", "Shredded Paper", "Paper Plates", "Paper Cup", "Paper Towel", "Plastic Bucket"]
        self.countyPicker.dataSource = self
        self.countyPicker.delegate = self
        self.trashTypePicker.dataSource = self
        self.trashTypePicker.delegate = self
    }

    @IBAction func openLibrary(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary;
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    @IBAction func openCamera(_ sender: Any) {
        let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .camera;
            imagePicker.allowsEditing = false
        self.present(imagePicker, animated: true, completion: nil)
        
        }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[.originalImage] as! UIImage
        self.cameraImg.image = image
        dismiss(animated:true, completion: nil)
    }
    
    
    @IBOutlet weak var outputText: UILabel!
    
    @IBAction func checkButton(_ sender: Any) {
        if cameraImg.image == UIImage(named: "recycling"){
            outputText.text = "Result: Please Upload an Image :)"
            return
        }
        //var searches = UserDefaults.standard.array(forKey: "searches")
        
        checkRecyclable()
        self.search = [self.recycleable, self.countyChoice, self.trashType, self.cameraImg!]
        //searches?.append(search)
        //saveSearch(searches as! [NSArray])
        outputText.text = self.resultString
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == countyPicker{
            return countyData.count
        }else{
            return trashData.count
        }
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == countyPicker{
            return countyData[row]
        }else {
            return trashData[row]
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == countyPicker{
            self.countyChoice = countyData[row]
        }else{
            self.trashType = trashData[row]
        }
         
    }
    
    func checkRecyclable(){
        //"Benton", "Clackamas", "Lane","Linn", "Marion","Multnomah"
        let county = self.countyChoice
        let material = self.trashType
        let yesMarion: [String] = ["Plastic Bottles","Jug","Cardboard","Paper","Can","Aluminum", "Milk/ Juice Carton"]

        let yesMult: [String] = ["Plastic Bottles","Jug","Cardboard","Metal Tin","Aluminum"]

        let yesBenton: [String] = ["Plastic Bottles","Jug","Cardboard","Metal Tin","Aluminum"]

        let yesClack: [String] = ["Newspaper, Cereal Boxes, Magazines, Catalogs, Office Paper, Milk/ Juice Carton, Cardboard, Aluminum, Can, Aluminum Foil, Shredded Paper,Plastic Bucket"]

        let yesLane: [String] = ["Plastic Bottles","Jug","Cardboard","Metal Tin","Aluminum"]

        let yesLinn: [String] = ["Newspaper","Cereal Boxes","Magazines","Cardboard","Can","Aluminum", "Plastic Bottles", "Jugs", "Food Containers", "Catalogs", "Office Paper", "Milk/ Juice Carton"]
        switch county {
        case "Benton":
            if yesBenton.contains(material){
                self.resultString = "Result: That is Recyclable in Benton County!"
                self.recycleable = true
            }else{
                self.resultString = "Result: That is not Recyclable in Benton County :("
                self.recycleable = false
            }
        case "Clackamas":
            if yesClack.contains(material){
                self.resultString = "Result: That is Recyclable in Clackamas County!"
                self.recycleable = true
            }else{
                self.resultString = "Result: That is not Recyclable in Clackamas County :("
                self.recycleable = false
            }
        case "Lane":
            if yesLane.contains(material){
                self.resultString = "Result: That is Recyclable in Lane County!"
                self.recycleable = true
            }else{
                self.resultString = "Result: That is not Recyclable in Lane County :("
                self.recycleable = false
            }
        case "Linn":
            if yesLinn.contains(material){
                self.resultString = "Result: That is Recyclable in Linn County!"
                self.recycleable = true
            }else{
                self.resultString = "Result: That is not Recyclable in Linn County :("
                self.recycleable = false
            }
        case "Marion":
            if yesMarion.contains(material){
                self.resultString = "Result: That is Recyclable in Marion County!"
                self.recycleable = true
            }else{
                self.resultString = "Result: That is not Recyclable in Marion County :("
                self.recycleable = false
            }
        default:
            if yesMult.contains(material){
                self.resultString = "Result: That is Recyclable in Multnomah County!"
                self.recycleable = true
            }else{
                self.resultString = "Result: That is not Recyclable in Multnomah County :("
                self.recycleable = false
            }
        }
       
    }
   // let userDef = UserDefaults.standard
    
    //func saveSearch(_ newSearches: [NSArray]){
      //  userDef.set(newSearches, forKey: "searches")
        
   // }
}

