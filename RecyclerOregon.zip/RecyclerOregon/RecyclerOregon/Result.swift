//
//  CheckResults.swift
//  RecyclerOregon
//
//  Created by Sadanand Lakka on 11/17/19.
//  Copyright © 2019 SQO. All rights reserved.
//

import Foundation
import UIKit
class Result : NSObject, NSCoding {
    let pic : UIImage
    let county: String
    let trash: String
    let result: Bool
    
    init(pic: UIImage, county: String, trash: String, result: Bool) {
        self.pic = pic
        self.county = county
        self.trash = trash
        self.result = result
        super.init()
    }
    required init?(coder aDecoder: NSCoder) {
        if let decodedData = aDecoder.decodeObject(forKey: "pic") as? UIImage {
            self.pic = decodedData
        }else{
            self.pic = UIImage()
        }
        self.county = aDecoder.decodeObject(forKey: "county") as! String
        self.trash = aDecoder.decodeObject(forKey: "trash") as! String
        self.result = aDecoder.decodeBool(forKey: "result")
    }
    func encode(with coder: NSCoder) {
        
    }
    
    
    
    
}
